
document.addEventListener('DOMContentLoaded', () => {
    const postsContainer = document.getElementById('postsContainer');
    const newPostBtn = document.getElementById('newPostBtn');
    const loginBtn = document.getElementById('loginBtn');

    // Fetch posts from the server
    async function fetchPosts() {
        const response = await fetch('/api/posts');
        const posts = await response.json();
        renderPosts(posts);
    }

    // Function to render posts
    function renderPosts(posts) {
        postsContainer.innerHTML = '';
        posts.forEach(post => {
            const postDiv = document.createElement('div');
            postDiv.classList.add('post');
            postDiv.innerHTML = `<strong>${post.user}:</strong> <p>${post.content}</p>`;
            postsContainer.appendChild(postDiv);
        });
    }

    // Add a new post
    newPostBtn.addEventListener('click', async () => {
        const newContent = prompt("Enter your post content:");
        if (newContent) {
            const response = await fetch('/api/posts', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user: 'You', content: newContent })
            });
            if (response.ok) {
                fetchPosts();
            }
        }
    });

    // Mock login
    loginBtn.addEventListener('click', () => {
        alert("Login functionality coming soon!");
    });

    fetchPosts();
});
